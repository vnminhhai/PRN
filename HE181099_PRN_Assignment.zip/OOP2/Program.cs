﻿using System.Linq.Expressions;

namespace OOP2
{
    public abstract class Person
    {
        private String name { get; set; }
        private String address { get; set; }

        public string getName()
        {
            return name;
        }
        public string getAddress() { return address; }

        public void setName(string nam)
        {
            name = nam;
        }
        public void setAddress(string address)
        {
            this.address = address;
        }
        public string toString()
        {
            return "Name: " + name + " Address: " + address;
        }
    }

    public class Employee : Person
    {
        private int salary;
        public Employee(String name, string address, int salary)
        {
            base.setName(name);
            base.setAddress(address);
            this.salary = salary;
        }

        public int getSalary()
        {
            return salary;
        }
        public void display()
        {
            Console.WriteLine("Name: " + base.getName() + " Salary: " + salary);
        }
    }

    public class Customer: Person
    {
        private int balance;

        public int getBalance()
        {
            return balance; 
        }
        public Customer(String name, string address, int balance)
        {
            base.setName(name);
            base.setAddress(address);
        }
        public new string toString()
        {
            return "Name: " + base.getName() + " Balance: " + balance;
        }
    }
    public class MainProgram
    {
        public static void Main(string[] args)
        {
            List<Person> list1 = new List<Person>();
            while (true)
            {
                Console.WriteLine("Choose a function: ");
                Console.WriteLine("1. Find Persons with highest salary/balance");
                Console.WriteLine("2. Find Persons by name");
                Console.WriteLine("3. Add an Person: ");
                Console.WriteLine("0. End program");
                string i = Console.ReadLine();
                switch (i)
                {
                    case "0": return;
                    case "1":
                        //Search
                        Customer p = null; Employee f = null;
                        foreach (Person Person in list1)
                        {
                            if (Person is Customer)
                                if (p == null || p.getBalance() < ((Customer)Person).getBalance())
                                    p = (Customer)Person;
                            if (Person is Employee)
                                if (f == null || f.getSalary() < ((Employee)Person).getSalary())
                                    f = (Employee)Person;
                        }
                        if (p == null) Console.WriteLine("No Customer found");
                        else
                        {
                            Console.WriteLine("Customer with highest balance:");
                            Console.WriteLine(p.toString());
                        }
                        if (f == null) Console.WriteLine("No Employee found");
                        else
                        {
                            Console.WriteLine("Employee with highest salary:");
                            Console.WriteLine(f.toString());
                        }
                        Console.ReadLine();
                        break;
                    case "2":
                        Console.Write("Enter a name:");
                        string s = Console.ReadLine();
                        //Search
                        foreach (Person Person in list1)
                        {
                            if (Person.getName() == s)
                                Console.WriteLine(Person.toString());
                        }
                        Console.WriteLine();
                        Console.ReadLine();
                        break;
                    case "3":
                        Console.WriteLine("Add an Person: ");
                        Console.WriteLine("A customer? (Y/N)");
                        s = Console.ReadLine().ToLower();
                        string name, add=null;
                        if (s == "y")
                        {
                            int bal;
                            Console.Write("Enter a name: ");
                            try
                            {
                                name = Console.ReadLine();
                                if (name == null || name == "") throw new Exception();
                            } catch (Exception e)
                            {
                                Console.WriteLine("Name can not be empty");
                                break;
                            }
                            
                            Console.Write("Enter balance: ");
                            try
                            {
                                bal = int.Parse(Console.ReadLine());
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Your input was not a valid number");
                                break;
                            }
                            Console.Write("Enter address: ");
                            try
                            {
                                add = Console.ReadLine();
                                if (add == null || add =="") throw new Exception();
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Address can not be empty");
                                break;
                            }
                            list1.Add(new Customer(name, add, bal));
                        }
                        else if (s == "n")
                        {
                            int ph=-1;
                            Console.Write("Enter a name: ");
                            try
                            {
                                name = Console.ReadLine();
                                if (name == null || name == "") throw new Exception();
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Name can not be empty");
                                break;
                            }
                            Console.Write("Enter address: ");
                            try
                            {
                                add = Console.ReadLine();
                                if (add == null || add == "") throw new Exception();
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Address can not be empty");
                                break;
                            }
                            Console.Write("Enter salary: ");
                            try
                            {
                                ph = int.Parse(Console.ReadLine());
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("You did not input a valid number");
                                break;
                            }
                            list1.Add(new Employee(name, add, ph));
                        }
                        else Console.WriteLine("Invalid input");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Invalid input");
                        Console.ReadLine();
                        break;
                }
            }
        }
    }
}
