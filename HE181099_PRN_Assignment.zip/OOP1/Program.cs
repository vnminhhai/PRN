﻿using System.Xml.Linq;

namespace OOP1
{
    public interface IEmployee
    {
        public int calculateSalary();
        public string getName();
    }

    public abstract class Employee:IEmployee
    {
        private String name { get; set; }
        private int paymentPerHour { get; set; }

        public abstract int calculateSalary();

        public string getName()
        {
            return name;
        }
        public int getPaymentPerHour() {  return paymentPerHour; }

        public void setName(string nam)
        {
            name = nam;
        }
        public void setPaymentPerHour(int paymentPerHour)
        {
            this.paymentPerHour = paymentPerHour;
        }
        public string toString()
        {
            return "Name: "+name+" Payment per hour: "+paymentPerHour;
        }
    }
    public class PartTimeEmployee : Employee
    {
        private int workingHours;
        public PartTimeEmployee(String name, int pay, int workingHours)
        {
            base.setName(name);
            base.setPaymentPerHour(pay);
            this.workingHours = workingHours;
        }
        public override int calculateSalary()
        {
            return workingHours*base.getPaymentPerHour();
        }
        public new string toString()
        {
            return "Name: " + base.getName() + " Salary per hour: " + calculateSalary();
        }
    }

    public class FullTimeEmployee : Employee
    {
        public FullTimeEmployee(String name, int pay)
        {
            base.setName(name);
            base.setPaymentPerHour(pay);
        }
        public override int calculateSalary()
        {
            return 8 * base.getPaymentPerHour();
        }
        public new string toString()
        {
            return "Name: " + base.getName() + " Salary per hour: " + calculateSalary();
        }
    }

    public class MainProgram
    {
        public static void Main(string[] args)
        {
            List<Employee> list1 = new List<Employee>();
            while (true)
            {
                Console.WriteLine("Choose a function: ");
                Console.WriteLine("1. Find employees with highest salary");
                Console.WriteLine("2. Find employees by name");
                Console.WriteLine("3. Add an employee: ");
                Console.WriteLine("0. End program");
                string i = Console.ReadLine();
                switch (i)
                {
                    case "0": return;
                    case "1":
                        //Search
                        PartTimeEmployee p=null; FullTimeEmployee f=null;
                        foreach (Employee employee in list1)
                        {
                            if (employee is PartTimeEmployee)
                                if (p == null || p.calculateSalary()<employee.calculateSalary())
                                    p = (PartTimeEmployee)employee;
                            if (employee is FullTimeEmployee)
                                if (f == null || f.calculateSalary() < employee.calculateSalary())
                                    f = (FullTimeEmployee)employee;
                        }
                        if (p == null) Console.WriteLine("No part time employee found");
                        else
                        {
                            Console.WriteLine("Part time employee with highest salary:");
                            Console.WriteLine(p.toString());
                        }
                        if (f == null) Console.WriteLine("No full time employee found");
                        else
                        {
                            Console.WriteLine("Full time employee with highest salary:");
                            Console.WriteLine(f.toString());
                        }
                        Console.ReadLine();
                        break;
                    case "2":
                        Console.Write("Enter a name:");
                        string s = Console.ReadLine();
                        //Search
                        foreach (Employee employee in list1)
                        {
                            if (employee.getName() == s)
                                Console.WriteLine(employee.toString());
                        }
                        Console.WriteLine();
                        Console.ReadLine();
                        break;
                    case "3":
                        Console.WriteLine("Add an employee: ");
                        Console.WriteLine("A part time employee? (Y/N)");
                        s = Console.ReadLine().ToLower();
                        if (s=="y")
                        {
                            Console.Write("Enter a name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter salary per hour: ");
                            int ph = int.Parse(Console.ReadLine());
                            Console.Write("Enter work hour: ");
                            int wh = int.Parse(Console.ReadLine());
                            list1.Add(new PartTimeEmployee(name, ph, wh));
                        }
                        else if (s == "n")
                        {
                            Console.Write("Enter a name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter salary per hour: ");
                            int ph = int.Parse(Console.ReadLine());
                            list1.Add(new FullTimeEmployee(name, ph));
                        }
                        else Console.WriteLine("Invalid input");
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Invalid input");
                        Console.ReadLine();
                        break;
                }
            }
        }
    }
}
